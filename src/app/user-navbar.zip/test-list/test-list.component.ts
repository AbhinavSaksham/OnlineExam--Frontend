import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { ExamService } from '../exam.service';
import { test_List } from '../Models/test_Lists';



@Component({
  selector: 'app-test-list',
  templateUrl: './test-list.component.html',
  styleUrls: ['./test-list.component.css']
})
export class TestListComponent {

  tid: number=0;

  tests: test_List[]=[];
  constructor(private _service: ExamService,private activatedrouter: ActivatedRoute) { }
  
  ngOnInit(): void {
    this.tid=this.activatedrouter.snapshot.params["subject_Id"];
    console.log(this.tid);
    this._service.getTests(this.tid).subscribe(data=>{
      this.tests=data;
      console.log(this.tests);
    });

  }

}
